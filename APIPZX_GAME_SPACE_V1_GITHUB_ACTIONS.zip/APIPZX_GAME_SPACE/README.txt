APIPZX GAME SPACE V1
Android WebView project with burgundy Saitama theme.
Features: Home dashboard, drag sensitivity preference sliders, macro sequence template editor (no automated touch injection), graphics preference presets, animation/effect settings.
Important: presets are local reference settings and do not force changes inside third-party games or bypass their protections.

BUILD:
1. Extract this ZIP.
2. Open folder APIPZX_GAME_SPACE in Android Studio.
3. Allow Gradle sync and install any requested Android SDK components.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK in app/build/outputs/apk/debug/ after a successful build.


BUILD APK VIA GITHUB ACTIONS (PHONE-FRIENDLY)
1. Extract this ZIP on your phone.
2. Create a GitHub repository and upload the CONTENTS of the APIPZX_GAME_SPACE folder (not the enclosing folder).
3. Ensure .github/workflows/android.yml is uploaded at repository root.
4. Open the repository on GitHub, select Actions, then "Build APIPZX GAME SPACE APK".
5. If prompted, enable Actions. Choose "Run workflow" if no automatic run started.
6. Wait for the green successful run. Open that run, scroll to Artifacts, and download APIPZX-GAME-SPACE-V1-debug-apk.
7. Extract the downloaded artifact ZIP; install app-debug.apk on your Android phone. Android may ask permission to install unknown apps for the browser/file manager.

This produces a DEBUG APK for testing, not a Play Store release. The current app's drag, macro and graphics controls are local preference/demo tools; they do not inject touches or change other games' internal settings.
