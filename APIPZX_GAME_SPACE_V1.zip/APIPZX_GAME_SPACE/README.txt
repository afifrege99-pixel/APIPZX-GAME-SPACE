APIPZX GAME SPACE V1
Android WebView project with burgundy Saitama theme.
Features: Home dashboard, drag sensitivity preference sliders, macro sequence template editor (no automated touch injection), graphics preference presets, animation/effect settings.
Important: presets are local reference settings and do not force changes inside third-party games or bypass their protections.

BUILD:
1. Extract this ZIP.
2. Open folder APIPZX_GAME_SPACE in Android Studio.
3. Allow Gradle sync and install any requested Android SDK components.
4. Build > Build Bundle(s) / APK(s) > Build APK(s).
5. Find the APK in app/build/outputs/apk/debug/ after a successful build.
